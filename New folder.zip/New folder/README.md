# React Mixpanel Example

To run this example you will need:

1. Your Mixpanel `key` (or use included one in example, you can log in to Mixpanel dashboard with, l: `c602781@trbvn.com`, p: `c602781@trbvn.com`, but shh...)
2. Run install command: `npm i` or `yarn`
3. Run the app: `npm start` or `yarn start`
4. Enter the website: `http://localhost:3000/` and see your console logs and Mixpanel dashboard.
