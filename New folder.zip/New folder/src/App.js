import React from 'react';
import PropTypes from 'prop-types';
import ReactDOM from 'react-dom';
import mixpanel from 'mixpanel-browser';
import {MixpanelProvider, MixpanelConsumer} from "react-mixpanel";
import MixpanelAwareComponent from './Mixpanel';


class App extends React.Component {
	render() {
		return <MixpanelAwareComponent/>
	}
}

export default App;