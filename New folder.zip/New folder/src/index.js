import React from 'react';
import PropTypes from 'prop-types';
import ReactDOM from 'react-dom';
import mixpanel from 'mixpanel-browser';
import {MixpanelProvider, MixpanelConsumer} from "react-mixpanel";
import App from './App';


// initialize mixpanel
mixpanel.init('29437c45fd2e48b93a0e95fa24682e66');

// Root app
// class App extends React.Component {
// 	render() {
// 		return <MixpanelAwareComponent/>
// 	}
// }

// // Component that will be aware of Mixpanel existence - it will pass Mixpanel
// // instance down to it's child
// class MixpanelAwareComponent extends React.Component {
// 	render() {
// 		return <MixpanelConsumer>
// 			{mixpanel => <MixpanelDependantComponent mixpanel={mixpanel}/>}
// 		</MixpanelConsumer>
// 	}
// }

// // Proper Mixpanel consumer, it gets Mixpanel instance by props
// class MixpanelDependantComponent extends React.Component {
// 	static propTypes = {
// 		mixpanel: PropTypes.object.isRequired,
// 	};
	
// 	componentDidMount() {
// 		const {mixpanel} = this.props;
// 		mixpanel.track('App, LoginUser');
// 		console.info(`"App, componentDidMount" sent!`);
// 		mixpanel.identify("123456");
// 		mixpanel.people.set({
// 			"$name": "Sahshikant Tiwari",
// 			"$email": "shashikant@gmail.com",    // only special properties need the $
			
// 			"$created": "2020-01-20 16:53:54",
// 			"$last_login": new Date(),         // properties can be dates...
			
// 			"credits": 200,                    // ...or numbers
			
// 			"gender": "Male"                    // feel free to define your own properties
// 		});
// 	}
	
// 	render() {
// 		return <div>Hello World! Please check the console.</div>;
// 	}
// }

ReactDOM.render(<MixpanelProvider mixpanel={mixpanel}>
	<App/>
</MixpanelProvider>, document.getElementById('root'));
